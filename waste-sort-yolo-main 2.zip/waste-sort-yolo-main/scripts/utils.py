#
from datetime import datetime
import os
import wandb
from ultralytics import YOLO, settings

# 修改 train 函数，增加 **kwargs 接收额外参数
def train(model, config, weight_path=None, **kwargs):
    # load pretrained weight
    if weight_path is not None:
        model.load(weight_path)
    
    run_name = kwargs.get("run_name_override", datetime.now().strftime("%Y%m%d_%H%M%S"))
    
    # wandb init (保留原有逻辑，稍微调整 name)
    wandb.init(
        project=config["project"],
        name=run_name,
        tags=config["tags"] + kwargs.get("extra_tags", []),
        config={
            "model_type": config["model"],
            "pretrain_weight": config["pretrained_weight"],
            "dataset": config["data_path"],
            **kwargs # 记录额外的超参数
        },
    )

    # 准备训练参数，合并 config 和 kwargs
    train_args = {
        "name": run_name,
        "data": config["data_path"],
        "epochs": config["num_epochs"],
        "batch": config["batch_size"],
        "imgsz": config["image_size"],
        "device": config["device"],
        "workers": config["workers"],
        "patience": config["patience"],
    }
    
    # 将 main.py 传来的特定改进参数加入训练参数
    # 例如：box (Loss gain), cls, dropout, mosaic 等
    valid_keys = ["box", "cls", "dfl", "iou", "lr0", "lrf", "optimizer", "close_mosaic", "dropout"]
    for k, v in kwargs.items():
        if k in valid_keys:
            train_args[k] = v

    # train
    results = model.train(**train_args) # 使用解包传递所有参数
    
    # 获取 metrics (修复之前的 NameError 问题)
    metrics = {
        "mAP50": results.results_dict.get("metrics/mAP50(B)", 0),
        "mAP50-95": results.results_dict.get("metrics/mAP50-95(B)", 0),
        "precision": results.results_dict.get("metrics/precision(B)", 0),
        "recall": results.results_dict.get("metrics/recall(B)", 0),
    }
    
    print("\n" + "="*50)
    print(f"Final Training Metrics ({run_name}):")
    print("="*50)
    for key, value in metrics.items():
        print(f"{key}: {value:.4f}")
    print("="*50 + "\n")
    
    # 结束 wandb run 以便开始下一个
    wandb.finish()
    
    return results

# test 函数保持不变，或者记得修复里面的 metrics 打印问题