#
import os
import argparse
from ultralytics import YOLO
from scripts.utils import *
from scripts.train import *

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# 基础配置 (保持不变)
BASE_CONFIG = {
    "project": "wastesorting100epoch",
    "model": "yolov8n.yaml", 
    "pretrained_weight": os.path.join(ROOT_DIR, "weights", "yolov8n.pt"),
    "tags": ["baseline"],
    "data_path": os.path.join(ROOT_DIR, "data", "GARBAGE-CLASSIFICATION-3-2", "data.yaml"),
    "num_epochs": 100,
    "batch_size": 16,
    "image_size": 640,
    "device": 0,  
    "workers": 8,
    "patience": 20,
}

def parse_args():
    parser = argparse.ArgumentParser()
    # 保持原有参数解析逻辑不变
    subparsers = parser.add_subparsers(dest="mode", help="mode", required=True)
    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--run_name", type=str, help="optional load weight")
    test_parser = subparsers.add_parser("test")
    test_parser.add_argument("run_name", type=str)
    convert_parser = subparsers.add_parser("convert")
    convert_parser.add_argument("--path", type=str, required=True)
    return parser.parse_args()

def main():
    args = parse_args()
    
    # 这里的 wandb_login 建议修改为从环境变量读取，或者保持原样
    wandb_login() 
    set_settings(ROOT_DIR)

    if args.mode == "train":
        print("Starting Multi-Model Training Experiment...")
        
        # 定义三个实验的配置
        experiments = [
            # -------------------------------------------------------------
            # 模型 1: 模拟 Attention (Feature Focus)
            # 目标: 让模型更关注重要特征，抑制背景噪声。
            # 实现: 通过增加 dropout (模拟抑制) 和 Cosine LR (更平滑的收敛)，
            #       并使用更强的 mosaic 关闭策略来让模型在后期专注于纯特征。
            # -------------------------------------------------------------
            {
                "name": "Exp1_Attention_Focus",
                "params": {
                    "dropout": 0.1,    # 增加 Dropout，模拟注意力机制中的“抑制不相关特征”
                    "optimizer": "AdamW", # 使用 AdamW 优化器，通常对特征选择更稳健
                    "close_mosaic": 20, # 提前关闭马赛克增强，让模型最后 20 epoch 专注真实图像特征
                    "extra_tags": ["attention_proxy", "dropout_focus"]
                }
            },
            
            # -------------------------------------------------------------
            # 模型 2: 模拟 AFE Neck (Small Object / Feature Fusion)
            # 目标: 增强多尺度特征融合，提升小物体检测。
            # 实现: 增大输入分辨率 (imgsz)，降低 Box Loss 权重以换取更高的 Recall，
            #       增加 DFL (Distribution Focal Loss) 权重以提升难样本的定位。
            # -------------------------------------------------------------
            {
                "name": "Exp2_Neck_Fusion",
                "params": {
                    "image_size": 1280, # [关键] 增大分辨率是提升 Neck 对小物体融合能力的直接手段
                    "dfl": 2.0,         # 增加 DFL Loss 权重，强化对精细特征的对齐
                    "box": 5.0,         # 稍微降低 box 权重，避免过拟合大物体
                    "extra_tags": ["neck_proxy", "high_res_fusion"]
                }
            },
            
            # -------------------------------------------------------------
            # 模型 3: 模拟 WIoU Loss (Loss Function Improvement)
            # 目标: 优化边界框回归，减轻离群点干扰。
            # 实现: 调整 box 和 iou 参数。虽然不能直接改代码变 WIoU，
            #       但可以通过大幅提高 box gain 并降低 iou 阈值来模拟 WIoU 
            #       "通过动态权重关注高质量锚框" 的策略。
            # -------------------------------------------------------------
            {
                "name": "Exp3_Loss_Improvement",
                "params": {
                    "box": 10.0,  # [关键] 大幅提高 Box Loss 权重 (默认是 7.5)，强调定位准确性
                    "cls": 0.3,   # 降低分类权重，让模型专注于“框得准”
                    "iou": 0.6,   # 调整 NMS 的 IoU 阈值
                    "extra_tags": ["loss_proxy", "box_focus"]
                }
            }
        ]

        # 循环训练
        for i, exp in enumerate(experiments):
            print(f"\n\n>>> Starting Training {i+1}/{len(experiments)}: {exp['name']}")
            
            # 复制基础配置
            current_config = BASE_CONFIG.copy()
            
            # 如果实验中覆盖了 config 里的基础参数 (如 image_size)，在这里更新
            if "image_size" in exp["params"]:
                current_config["image_size"] = exp["params"].pop("image_size")

            # 加载模型
            model = YOLO(current_config["model"])
            
            # 传递额外的 params 到 train 函数
            train(
                model, 
                current_config, 
                weight_path=current_config["pretrained_weight"], 
                run_name_override=exp["name"],
                **exp["params"] # 解包实验参数
            )
            
            print(f">>> Finished {exp['name']}\n")

    elif args.mode == "test":
        test(args.run_name, BASE_CONFIG) 
    
    elif args.mode == "convert":
        convert_to_tf(args.path)

if __name__ == "__main__":
    main()